package umc.PJR.domain.walkbook.mapping;

import jakarta.persistence.*;
import lombok.*;
import umc.PJR.domain.common.BaseEntity;
import umc.PJR.domain.enums.MissionStatus;

@Entity
@Getter
@Builder
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@AllArgsConstructor
public class MemberMission extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    private MissionStatus status;
}